from django import forms
from .models import UserProfile,Interest,TokenPackage,ProfilePicture
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from dal import autocomplete




class ProfilePictureForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['profile_picture']


class AdditionalPicturesForm(forms.ModelForm):
    class Meta:
        model = ProfilePicture
        fields = ['image']


class TokenGiftForm(forms.Form):
    recipient_username = forms.CharField(max_length=150, label="Recipient's Username")
    package = forms.ModelChoiceField(queryset=TokenPackage.objects.all(), label="Select Token Package")

    def clean_recipient_username(self):
        # Validate if the entered username exists
        username = self.cleaned_data['recipient_username']
        try:
            recipient = User.objects.get(username=username)
        except User.DoesNotExist:
            raise forms.ValidationError(f"No user with username '{username}' found.")
        return username



class UserRegistrationForm(forms.ModelForm):
    email = forms.EmailField(required=True)
    password1 = forms.CharField(
        label="Password",
        widget=forms.PasswordInput,
        required=True
    )
    password2 = forms.CharField(
        label="Password confirmation",
        widget=forms.PasswordInput,
        required=True
    )
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super(UserRegistrationForm, self).__init__(*args, **kwargs)
        # Remove the help text from the password fields
        self.fields['password1'].help_text = None
        self.fields['password2'].help_text = None

        # Ensure no additional fields or messages are included
        for field_name in self.fields:
            self.fields[field_name].help_text = None  # Remove help text
            self.fields[field_name].label_suffix = ''  # Optional: remove colon after labels

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2 and password1 != password2:
            raise ValidationError("Passwords do not match.")

        return cleaned_data

    def save(self, commit=True):
        # Save the User instance
        user = super(UserRegistrationForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        user.set_password(self.cleaned_data['password1'])  # Hash the password

        if commit:
            user.save()
        return user



class UserProfileForm(forms.ModelForm):


    # Input for Interests and Preferences
    interests = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter your interests...'}),
        required=False,
        label="Your Interests"
    )

    interest_preference = forms.CharField(
        widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter preferred interests...'}),
        required=False,
        label="Interests You Prefer in a Match"
    )

    



    class Meta:
        model = UserProfile
        fields = ['profile_picture', 'body_type', 'age', 'height','education','occupation','bio', 'interests', 'interest_preference',
                  'gender_preference', 'min_age_preference', 'max_age_preference', 'body_type_preference', 'smoking_preference', 
                  'drinking_preference', 'relationship_goal']

    def save(self, commit=True):
        instance = super().save(commit=False)
        # Process interests as comma-separated if not empty
        interests = self.cleaned_data.get('interests')
        if interests:
            instance.interests = [interest.strip() for interest in interests.split(',')]
        # Process interest preferences similarly
        interest_preferences = self.cleaned_data.get('interest_preference')
        if interest_preferences:
            instance.interest_preference = [preference.strip() for preference in interest_preferences.split(',')]
        
        if commit:
            instance.save()
        return instance
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        interests = self.cleaned_data.get('interests')
        if interests:
        # Split the interests string into individual values
            interests_list = [interest.strip() for interest in interests.split(',')]
            
            interest_objects = []
            for interest_name in interests_list:
                interest, created = Interest.objects.get_or_create(name=interest_name)
                interest_objects.append(interest)
                instance.interests.set(interest_objects)

    # Process interest preferences similarly
        interest_preferences = self.cleaned_data.get('interest_preference')
        if interest_preferences:
            interest_preferences_list = [preference.strip() for preference in interest_preferences.split(',')]
        # Set the interest preferences in a similar manner
            preference_objects = []
            for preference_name in interest_preferences_list:
                preference, created = Interest.objects.get_or_create(name=preference_name)
                preference_objects.append(preference)

                instance.interest_preference.set(preference_objects)

        if commit:
            instance.save()
        return instance
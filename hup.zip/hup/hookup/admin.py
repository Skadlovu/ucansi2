from django.contrib import admin
from .models import UserProfile, ProfilePicture,Interest,TokenPackage
from django import forms
from dal import autocomplete


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'profile_picture', 'profile_picture_approved')
    list_filter = ('profile_picture_approved',)

    actions = ['approve_picture', 'reject_picture']

    def approve_picture(self, request, queryset):
        queryset.update(profile_picture_approved=True)
        self.message_user(request, "Selected profile pictures have been approved.")
    
    def reject_picture(self, request, queryset):
        queryset.update(profile_picture_approved=False)
        self.message_user(request, "Selected profile pictures have been rejected.")
    
    approve_picture.short_description = "Approve selected profile pictures"
    reject_picture.short_description = "Reject selected profile pictures"

@admin.register(ProfilePicture)
class ProfilePictureAdmin(admin.ModelAdmin):
    list_display = ('user', 'image', 'timestamp')




class InterestAdminForm(forms.ModelForm):
    class Meta:
        model = Interest
        fields = ['name']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({'class': 'form-control'})

class InterestAdmin(admin.ModelAdmin):
    form = InterestAdminForm
    search_fields = ['name']

admin.site.register(Interest, InterestAdmin)
admin.site.register(TokenPackage)



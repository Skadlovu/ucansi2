from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from django.contrib.auth.models import User
from.models import UserProfile

from django.contrib import messages
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.deprecation import MiddlewareMixin
from django.utils.html import format_html

class ProfileCompletionMiddleware:
    """
    Enhanced middleware that checks profile completion and shows specific messages
    about missing information to users.
    """
    def __init__(self, get_response):
        self.get_response = get_response
        # Define paths that should bypass the middleware
        self.exempt_paths = [
            reverse('hookup:update_profile'),
            reverse('hookup:email_notice'),
            '/admin/',  # Bypass admin paths
            '/static/',  # Bypass static files
            '/media/',  # Bypass media files
        ]

    def __call__(self, request):
        if request.user.is_authenticated and not self._is_path_exempt(request.path):
            try:
                profile = request.user.userprofile
                missing_fields = self._check_profile_completion(profile)
                
                if not profile.is_email_verified:
                    messages.warning(
                        request,
                        format_html(
                            'Please verify your email address to access all features. '
                            '<a href="{}">Resend verification email</a>',
                            reverse('hookup:resend_verification')
                        )
                    )
                    return redirect('hookup:verify_email_notice')
                
                if missing_fields:
                    self._add_missing_fields_message(request, missing_fields)
                    return redirect('hookup:update_profile')
                
                if not profile.profile_picture_approved:
                    if self._is_restricted_action(request.path):
                        messages.warning(
                            request,
                            'Your profile picture needs to be approved before you can perform this action. '
                            'Please upload an appropriate profile picture.'
                        )
                        return redirect('hookup:upload_profile_picture')

            except AttributeError:
                messages.error(
                    request,
                    'Your profile needs to be set up. Please complete your profile information.'
                )
                return redirect('hookup:update_profile')

        return self.get_response(request)

    def _is_path_exempt(self, path):
        """Check if the current path should bypass the middleware."""
        return any(exempt_path in path for exempt_path in self.exempt_paths)

    def _is_restricted_action(self, path):
        """Check if the current path is a restricted action."""
        restricted_actions = [
            'send_wink',
            'send_like',
            'send_message',
        ]
        return any(action in path for action in restricted_actions)

    def _check_profile_completion(self, profile):
        """
        Check which required fields are missing from the profile.
        Returns a dictionary of missing fields and their descriptions.
        """
        missing_fields = {}
        
        required_fields = {
            'age': 'Age',
            'height': 'Height',
            'body_type': 'Body Type',
            'education': 'Education Level',
            'occupation': 'Occupation',
            'bio': 'Bio',
            'interests': 'Interests',
            
        }

        for field, description in required_fields.items():
            value = getattr(profile, field, None)
            if not value:
                missing_fields[field] = description

        return missing_fields

    def _add_missing_fields_message(self, request, missing_fields):
        """Add a detailed message about missing profile fields."""
        missing_fields_list = ', '.join(missing_fields.values())
        message = format_html(
            'Please complete your profile to access all features. Missing information: <strong>{}</strong><br>'
            'Click <a href="{}">here</a> to update your profile.',
            missing_fields_list,
            reverse('hookup:update_profile')
        )
        messages.warning(request, message)
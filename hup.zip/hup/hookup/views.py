from django.shortcuts import render, redirect,HttpResponse
from django.contrib.auth.decorators import login_required
from .forms import UserProfileForm,UserRegistrationForm,TokenGiftForm,AdditionalPicturesForm,ProfilePictureForm
from .models import UserProfile,Wink,Message,Like,TokenPackage,Subscription,ProfilePicture,Referral,Interest,haversine_distance
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import send_mail
from django.urls import reverse
from django.shortcuts import get_object_or_404, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync
from django.contrib import messages
from .utils import deduct_tokens,notify_token_update
from.consumers import notify_user
from django.db.models import Max
from django.core.exceptions import ValidationError  
from django.db import models  
from datetime import timedelta
from django.utils import timezone
import hashlib 
from urllib.parse import urlencode  
from django.conf import settings 
from django.contrib.auth import login
from django.db.models import Q
from django.contrib.auth import login, authenticate
from django.utils.http import url_has_allowed_host_and_scheme 
from dal import autocomplete



def home(request):
    """
    View for the landing page.
    """
    return render(request, 'hookup/home.html')





def user_search(request):
    """
    View to search for users by username, first name, or last name.
    """
    query = request.GET.get('q', '')
    results = []

    if query:
        # Perform the search query to find matching users by username, first name, or last name
        results = User.objects.filter(
            Q(username__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query)
        )

    return render(request, 'hookup/user_search_results.html', {'query': query, 'results': results})


@login_required
def connections_list(request):
    user=request.user

    likes_sent=User.objects.filter(sent_likes__sender=user)
    likes_received = User.objects.filter(received_likes__receiver=user)

    # Get all users the logged-in user has winked or received winks from
    winks_sent = User.objects.filter(sent_winks__sender=user)
    winks_received = User.objects.filter(received_winks__receiver=user)

    # Get all users the logged-in user has messaged or received messages from
    messages_sent = User.objects.filter(sent_messages__sender=user)
    messages_received = User.objects.filter(received_messages__receiver=user)

    # Combine all the unique users in one set (to avoid duplicates)
    connections = set(
        likes_sent.union(likes_received, winks_sent, winks_received, messages_sent, messages_received)
    )

    return render(request, 'hookup/connections_list.html', {'connections': connections})


@login_required
def generate_referral_link(request):
    referral, created= Referral.objects.get_or_create(referrer=request.user)
    referral_link=request.build_absolute_uri(referral.get_referral_link())
    return render(request, 'hookup/referral_link.html', {'referral_link': referral_link})



def signup_with_referral(request, referral_code):
    """
    Handle sign-up through a referral link. If the referral code is valid, link the new user to the referrer.
    """
    referral = get_object_or_404(Referral, referral_code=referral_code)
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            with transaction.atomic():
                user = form.save()
                # Link the new user to the referral
                referral.referred_user = user
                referral.referrer_awarded = False  # Initialize as False
                referral.save()
                
                login(request, user)
                return redirect('hookup:profile_update')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'hookup/signup_with_referral.html', {'form': form})






def send_match_email(user, match):
    subject = "New Match Found!"
    message = f"Hello {user.username}, you have a new match: {match.username}. Check their profile now!"
    from_email = settings.DEFAULT_FROM_EMAIL  # Use the configured default "From" email

    send_mail(
        subject,
        message,
        from_email,  # Uses noreply@xxxworld.online as configured in settings.py
        [user.email],  # The recipient's email
        fail_silently=False,  # Ensures errors are raised if email sending fails
    )


def verify_email_notice(request):
    return render(request, 'hookup/verify_email_notice.html')



def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()  # Save the form and get the user instance
            send_verification_email(user, request)  # Trigger email verification after registration
            return redirect('hookup:email_notice')  # Redirect to a page asking them to check their email
    else: 
        form = UserRegistrationForm()
    return render(request, 'hookup/register.html', {'form': form})


@login_required
def update_profile(request):
    profile = request.user.userprofile
    
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            with transaction.atomic():  # Use transaction to ensure data consistency
                # First, check if this is the user's first time completing their profile
                is_first_completion = not profile.is_profile_completed
                
                # Save the form
                profile_instance = form.save(commit=False)
                
                # Mark the profile as completed if all required fields are filled
                if _is_profile_complete(profile_instance):
                    profile_instance.is_profile_completed = True
                    
                    # Award tokens only if this is their first time completing the profile
                    # and they haven't received the signup bonus yet
                    if is_first_completion and not profile_instance.signup_bonus_awarded:
                        # Award tokens to the new user
                        award_tokens(
                            request.user, 
                            25, 
                            "Welcome! Your profile is complete and you've been awarded 25 free tokens to get started!"
                        )
                        profile_instance.signup_bonus_awarded = True
                        
                        # Check if user was referred and award referrer
                        try:
                            referral = Referral.objects.get(
                                referred_user=request.user,
                                referrer_awarded=False  # Make sure we haven't awarded tokens already
                            )
                            # Award tokens to the referrer
                            award_tokens(
                                referral.referrer, 
                                30, 
                                f"You've earned 30 tokens because {request.user.username} completed their profile!"
                            )
                            # Mark referral as awarded
                            referral.referrer_awarded = True
                            referral.save()
                            
                        except Referral.DoesNotExist:
                            # User wasn't referred, continue normally
                            pass
                    else:
                        messages.success(request, 'Your profile has been updated successfully!')
                
                profile_instance.save()
            
            return redirect('hookup:connections_list')
    else:
        form = UserProfileForm(instance=profile)

    return render(request, 'hookup/update_profile.html', {
        'form': form,
        'is_new_profile': not profile.is_profile_completed
    })


def _is_profile_complete(profile):
    """
    Check if all required profile fields are filled out.
    """
    required_fields = [
        profile.age,
        profile.height,
        profile.body_type,
        profile.education,
        profile.occupation,
        profile.profile_picture,
        profile.bio,

    ]
    
    return all(required_fields)



def send_verification_email(user, request):
    token = default_token_generator.make_token(user)
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    
    # Use the namespaced URL name
    verification_link = request.build_absolute_uri(
        reverse('hookup:verify_email', kwargs={'uidb64': uid, 'token': token})
    )
    
    subject = 'Verify your email address'
    message = render_to_string('hookup/email_verification.html', {
        'user': user,
        'verification_link': verification_link
    })
    
    send_mail(
        subject,
        message,
        settings.DEFAULT_FROM_EMAIL,
        [user.email],
        fail_silently=False,
    )

def verify_email(request, uidb64, token):
    try:
        # Decode the user ID and fetch the user
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = get_object_or_404(User, pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        # Get or create the UserProfile
        profile, created = UserProfile.objects.get_or_create(user=user)
        profile.is_email_verified = True
        profile.save()

        messages.success(request, 'Email verified! Please log in and complete your profile.')
        return redirect('hookup:hookup_login')
    else:
        # Invalid token or user not found, handle the error
        messages.error(request, 'Invalid or expired verification link. Please try again.')
        return redirect('hookup:hookup_login')
    


@login_required
def match_list(request):
    user_profile = request.user.userprofile

    # Use the MatchManager's find_matches method
    matches = UserProfile.objects.find_matches(request.user, max_distance_km=50)

    # Get non-matches: users within 50 km who do not meet the user's preferences
    all_nearby_users = UserProfile.objects.exclude(user=request.user).filter(
        latitude__isnull=False, longitude__isnull=False
    )
    
    non_matches = []
    for candidate in all_nearby_users:
        distance = haversine_distance(user_profile.latitude, user_profile.longitude, candidate.latitude, candidate.longitude)
        if distance <= 50 and candidate not in matches:
            non_matches.append(candidate)

    # Pass the information whether there are any matches or not
    context = {
        'matches': matches,
        'non_matches': non_matches,
        'user_location': {'lat': user_profile.latitude, 'lng': user_profile.longitude},
        'has_matches': bool(matches),  # Will be True if matches exist, False otherwise
    }
    return render(request, 'hookup/match_list.html', context)

@login_required
def profile_detail(request, user_id):
    profile = get_object_or_404(UserProfile, user__id=user_id)
    return render(request, 'hookup/profile_detail.html', {'profile': profile})


def notify_user_of_match(user, match_data):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f"user_{user.id}",
        {
            'type': 'send_new_match_notification',
            'match_data': match_data
        }
    )

@login_required
def send_message(request, user_id):
    receiver = get_object_or_404(User, pk=user_id)
    sender = request.user
    
    if request.method == 'POST':
        content = request.POST.get('message_content')
        try:
            # Deduct 1 token for sending a message
            deduct_tokens(sender, 1)
            
            # Create Message object
            Message.objects.create(sender=sender, receiver=receiver, content=content)

            # Notify the user of token balance update
            notify_token_update(sender)
            
            messages.success(request, f'Message sent to {receiver.username}!')
            return redirect('hookup:messages_list', user_id=user_id)
        
        except ValidationError as e:
            messages.error(request, str(e))
            return redirect('hookup:profile_detail', user_id=user_id)
    
    return render(request, 'hookup/send_message.html', {'receiver': receiver})

@login_required
def send_wink(request, user_id):
    receiver = get_object_or_404(User, pk=user_id)
    sender = request.user
    
    try:
        deduct_tokens(sender, 2)
        Wink.objects.create(sender=sender, receiver=receiver)
       
        notify_token_update(sender)
        
        # Send real-time notification to the receiver
        notify_user(receiver.id, 'wink', f'{sender.username} has sent you a wink!')
        
        messages.success(request, f'Wink sent to {receiver.username}!')
        return redirect('hookup:profile_detail', user_id=user_id)
    
    except ValidationError as e:
        messages.error(request, str(e))
        return redirect('hookup:profile_detail', user_id=user_id)


@login_required
def send_like(request, user_id):
    receiver = get_object_or_404(User, pk=user_id)
    sender = request.user
    
    try:
        # Deduct 1 token for a like
        deduct_tokens(sender, 1)
        
        # Create Like object
        Like.objects.create(sender=sender, receiver=receiver)

        notify_token_update(sender)
        
        # Notify the receiver (optional, can be an in-app notification)
        send_mail(
            f'{sender.username} liked your profile!',
            f'{sender.username} has liked your profile on the dating site!',
            'noreply@xxxworld.online',
            [receiver.email],
            fail_silently=False,
        )
        
        messages.success(request, f'You liked {receiver.username}\'s profile!')
        return redirect('hookup:profile_detail', user_id=user_id)
    
    except ValidationError as e:
        messages.error(request, str(e))
        return redirect('hookup:profile_detail', user_id=user_id)


@login_required
def messages_list(request):
    """
    Display the list of conversations where the logged-in user has exchanged messages.
    Only the most recent message in each conversation will be shown.
    """
    user = request.user
    
    # Find all unique users that the current user has sent or received messages from
    conversations = Message.objects.filter(
        models.Q(sender=user) | models.Q(receiver=user)
    ).values('sender', 'receiver').annotate(last_message_time=Max('timestamp')).order_by('-last_message_time')
    
    # Prepare the conversation list by grouping messages by sender/receiver
    unique_users = set()
    for conv in conversations:
        if conv['sender'] != user.id:
            unique_users.add(conv['sender'])
        if conv['receiver'] != user.id:
            unique_users.add(conv['receiver'])

    users_in_conversation = UserProfile.objects.filter(user__id__in=unique_users)

    return render(request, 'hookup/messages_list.html', {'conversations': users_in_conversation})


@login_required
def message_detail(request, user_id):
    """
    Display the entire conversation between the logged-in user and the selected user.
    """
    user = request.user
    other_user = get_object_or_404(User, pk=user_id)

    # Fetch the messages between the logged-in user and the selected user
    conversation = Message.objects.filter(
        models.Q(sender=user, receiver=other_user) | models.Q(sender=other_user, receiver=user)
    ).order_by('timestamp')  # Order by timestamp to show messages chronologically

    return render(request, 'hookup/message_detail.html', {
        'conversation': conversation,
        'other_user': other_user
    })


def generate_payfast_signature(data, passphrase=''):
    """Generates the PayFast signature for payment verification."""
    signature = '&'.join([f'{key}={value}' for key, value in sorted(data.items())])
    if passphrase:
        signature += f'&passphrase={passphrase}'
    return hashlib.md5(signature.encode()).hexdigest()

@login_required
def buy_tokens(request, package_id):
    package = TokenPackage.objects.get(pk=package_id)
    
    # PayFast credentials
    merchant_id = settings.PAYFAST_MERCHANT_ID
    merchant_key = settings.PAYFAST_MERCHANT_KEY
    return_url = settings.PAYFAST_RETURN_URL
    notify_url = settings.PAYFAST_NOTIFY_URL
    cancel_url = settings.PAYFAST_CANCEL_URL
    
    # Generate payment data for PayFast
    payment_data = {
        'merchant_id': merchant_id,
        'merchant_key': merchant_key,
        'return_url': return_url,
        'notify_url': notify_url,
        'cancel_url': cancel_url,
        'name_first': request.user.first_name,
        'name_last': request.user.last_name,
        'email_address': request.user.email,
        'm_payment_id': f'token_purchase_{package.id}_{request.user.id}',
        'amount': f'{package.price:.2f}',
        'item_name': f'Purchase {package.tokens} Tokens',
        'item_description': f'{package.tokens} tokens for R{package.price}',
    }
    
    # Generate signature
    signature = generate_payfast_signature(payment_data, settings.PAYFAST_PASSPHRASE)
    payment_data['signature'] = signature
    
    # Redirect to PayFast payment page
    return redirect(f"https://www.payfast.co.za/eng/process?{urlencode(payment_data)}")

@login_required
def buy_uncapped(request):
    # Redirect to PayFast for uncapped plan purchase (R 50)
    
    payment_data = {
        'merchant_id': settings.PAYFAST_MERCHANT_ID,
        'merchant_key': settings.PAYFAST_MERCHANT_KEY,
        'return_url': settings.PAYFAST_RETURN_URL,
        'notify_url': settings.PAYFAST_NOTIFY_URL,
        'cancel_url': settings.PAYFAST_CANCEL_URL,
        'name_first': request.user.first_name,
        'name_last': request.user.last_name,
        'email_address': request.user.email,
        'm_payment_id': f'uncapped_plan_{request.user.id}',
        'amount': '50.00',
        'item_name': 'Uncapped Plan for 30 Days',
        'item_description': 'Uncapped plan valid for 30 days.',
    }
    
    signature = generate_payfast_signature(payment_data, settings.PAYFAST_PASSPHRASE)
    payment_data['signature'] = signature

    return redirect(f"https://www.payfast.co.za/eng/process?{urlencode(payment_data)}")
    

def payfast_notify(request):
    if request.method == 'POST':
        # Extract necessary data from the request
        payment_id = request.POST.get('m_payment_id')
        amount = request.POST.get('amount_gross')

        # Verify the payment, the signature, etc. (follow PayFast documentation)

        # Example: handle token purchase
        if 'token_purchase' in payment_id:
            _, package_id, user_id = payment_id.split('_')
            package = TokenPackage.objects.get(id=package_id)
            user = User.objects.get(id=user_id)
            profile = user.userprofile
            
            # Add tokens to user's profile
            profile.tokens += package.tokens
            profile.save()

        # Example: handle uncapped plan purchase
        if 'uncapped_plan' in payment_id:
            _, user_id = payment_id.split('_')
            user = User.objects.get(id=user_id)

            # Activate a new subscription for 30 days
            Subscription.objects.create(user=user)
         
        if 'gift_tokens' in payment_id:
            # payment_id is in the format: gift_tokens_<package_id>_<buyer_id>_<recipient_id>
            _, package_id, buyer_id, recipient_id = payment_id.split('_')
            package = TokenPackage.objects.get(id=package_id)
            recipient = User.objects.get(id=recipient_id)

            # Add tokens to recipient's account
            recipient_profile = UserProfile.objects.get(user=recipient)
            recipient_profile.tokens += package.tokens
            recipient_profile.save()

        return HttpResponse(status=200)



@login_required
def token_purchase_view(request):
    """View for displaying available token packages and uncapped plan."""
    packages = TokenPackage.objects.all()  # Retrieve all available token packages
    return render(request, 'hookup/buy_tokens.html', {'packages': packages})




@login_required
def gift_tokens(request):
    if request.method == 'POST':
        form = TokenGiftForm(request.POST)
        if form.is_valid():
            recipient_username = form.cleaned_data['recipient_username']
            package = form.cleaned_data['package']
            
            # Find the recipient by username
            recipient = User.objects.get(username=recipient_username)
            
            # Redirect to PayFast for token purchase
            merchant_id = settings.PAYFAST_MERCHANT_ID
            merchant_key = settings.PAYFAST_MERCHANT_KEY
            return_url = settings.PAYFAST_RETURN_URL
            notify_url = settings.PAYFAST_NOTIFY_URL
            cancel_url = settings.PAYFAST_CANCEL_URL
            
            # Generate payment data for PayFast
            payment_data = {
                'merchant_id': merchant_id,
                'merchant_key': merchant_key,
                'return_url': return_url,
                'notify_url': notify_url,
                'cancel_url': cancel_url,
                'name_first': request.user.first_name,
                'name_last': request.user.last_name,
                'email_address': request.user.email,
                'm_payment_id': f'gift_tokens_{package.id}_{request.user.id}_{recipient.id}',  # Include both buyer and recipient
                'amount': f'{package.price:.2f}',
                'item_name': f'Purchase {package.tokens} Tokens for {recipient.username}',
                'item_description': f'{package.tokens} tokens for R{package.price} for user {recipient.username}',
            }
            
            # Generate PayFast signature
            def generate_payfast_signature(data, passphrase=''):
                signature = '&'.join([f'{key}={value}' for key, value in sorted(data.items())])
                if passphrase:
                    signature += f'&passphrase={passphrase}'
                return hashlib.md5(signature.encode()).hexdigest()
            
            signature = generate_payfast_signature(payment_data, settings.PAYFAST_PASSPHRASE)
            payment_data['signature'] = signature
            
            # Redirect to PayFast payment page
            return redirect(f"https://www.payfast.co.za/eng/process?{urlencode(payment_data)}")
    else:
        form = TokenGiftForm()
    
    return render(request, 'hookup/gift_tokens.html', {'form': form})

@login_required
def upload_profile_picture(request):
    """Allows the user to upload or update their profile picture."""
    profile = request.user.userprofile

    if request.method == 'POST':
        form = ProfilePictureForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            profile.profile_picture_approved = False  # Set to unapproved initially
            profile.save()
            messages.success(request, "Profile picture uploaded! Awaiting admin approval.")
            return redirect('hookup:profile_detail', user_id=request.user.id)
    else:
        form = ProfilePictureForm(instance=profile)
    
    return render(request, 'hookup/upload_profile_picture.html', {'form': form})

@login_required
def upload_additional_pictures(request):
    """Allows the user to upload up to 4 additional pictures."""
    user = request.user
    pictures = ProfilePicture.objects.filter(user=user)

    if request.method == 'POST':
        if pictures.count() < 4:
            form = AdditionalPicturesForm(request.POST, request.FILES)
            if form.is_valid():
                additional_picture = form.save(commit=False)
                additional_picture.user = user
                additional_picture.save()
                messages.success(request, "Additional picture uploaded.")
                return redirect('hookup:profile_detail', user_id=user.id)
        else:
            messages.error(request, "You can only upload up to 4 additional pictures.")
    else:
        form = AdditionalPicturesForm()
    
    return render(request, 'hookup/upload_additional_pictures.html', {'form': form, 'pictures': pictures})




@login_required
def likes_list(request):
    # Fetch all likes sent to the logged-in user
    likes = Like.objects.filter(receiver=request.user)

    # Mark all likes as viewed
    likes.update(viewed=True)

    return render(request, 'hookup/like_list.html', {'likes': likes})


@login_required
def winks_list(request):
    # Fetch all winks sent to the logged-in user
    winks = Wink.objects.filter(receiver=request.user)
    
    # Mark all winks as viewed
    winks.update(viewed=True)

    return render(request, 'hookup/wink_list.html', {'winks': winks})


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            # Check if the user's email is verified before allowing login
            try:
                profile = user.userprofile
                if not profile.is_email_verified:
                    messages.error(request, 'Please verify your email before logging in.')
                    return redirect('hookup:hookup_login')  # Stay on login page
            except UserProfile.DoesNotExist:
                messages.error(request, 'Profile not found. Please contact support.')
                return redirect('hookup:hookup_login')
            
            # Log in the user if the email is verified
            login(request, user)
            
            # Get the 'next' parameter or default to profile detail
            next_url = request.GET.get('next')
            if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
                return redirect(next_url)
            else:
                return redirect('hookup:match_list')  # Default redirect after login
        else:
            # If authentication fails, show an error message
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'hookup/login.html')
from django.core.exceptions import ValidationError
from channels.layers import get_channel_layer
from asgiref.sync import async_to_sync

def deduct_tokens(user, amount):
    """
    Deduct tokens from the user if they have enough. Raise ValidationError otherwise.
    """
    profile = user.userprofile
    if profile.tokens >= amount:
        profile.tokens -= amount
        profile.save()
        return True
    else:
        raise ValidationError("Insufficient tokens.")



def notify_token_update(user):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f"user_tokens_{user.id}",
        {
            'type': 'token_update',
            'token_balance': user.userprofile.tokens
        }
    )


from django.contrib import messages
from django.db import transaction

def award_tokens(user, amount, message=None):
    """
    Utility function to award tokens to a user and send WebSocket update
    """
    user.userprofile.tokens += amount
    user.userprofile.save()

    # Send real-time token update via WebSocket
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f"user_tokens_{user.id}",
        {
            "type": "token_update",
            "token_balance": user.userprofile.tokens
        }
    )

    if message:
        # If the user is currently online (has a session), show them a message
        from django.contrib.sessions.models import Session
        from django.utils import timezone
        sessions = Session.objects.filter(expire_date__gt=timezone.now())
        for session in sessions:
            if str(user.id) in session.get_decoded().get('_auth_user_id', ''):
                messages.success(user.request, message)

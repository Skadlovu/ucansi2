from django.urls import path
from .consumers import MatchConsumer

websocket_urlpatterns = [
    path('ws/matches/', MatchConsumer.as_asgi()),  # Define the WebSocket URL
]

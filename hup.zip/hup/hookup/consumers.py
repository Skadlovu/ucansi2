import json
from channels.generic.websocket import AsyncWebsocketConsumer
from .models import Message, UserProfile
from asgiref.sync import sync_to_async,async_to_sync
from channels.layers import get_channel_layer


class MessageConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        self.receiver_id = self.scope['url_route']['kwargs']['receiver_id']
        self.room_group_name = f'chat_{self.user.id}_{self.receiver_id}'
        
        # Join room group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave room group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    # Receive message from WebSocket
    async def receive(self, text_data):
        text_data_json = json.loads(text_data)
        message_content = text_data_json['message']
        
        # Deduct token and send message (if user has enough tokens)
        await self.deduct_token_and_send_message(message_content)
        
    # Deduct tokens and create the message
    @sync_to_async
    def deduct_token_and_send_message(self, message_content):
        profile = self.user.userprofile
        receiver = UserProfile.objects.get(user__id=self.receiver_id)
        
        if profile.tokens >= 1:
            profile.tokens -= 1
            profile.save()

            # Save message to database
            Message.objects.create(
                sender=self.user,
                receiver=receiver.user,
                content=message_content
            )

            # Notify the receiver in real time
            async_to_sync(self.channel_layer.group_send)(
                f'chat_{self.receiver_id}_{self.user.id}', {
                    'type': 'chat_message',
                    'message': message_content,
                    'sender': self.user.username,
                }
            )

    # Send message to WebSocket
    async def chat_message(self, event):
        message = event['message']
        sender = event['sender']

        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'message': message,
            'sender': sender,
        }))

class MatchConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        user = self.scope["user"]

        if user.is_authenticated:
            await self.channel_layer.group_add(
                f"user_{user.id}",  # Group each user by their unique ID
                self.channel_name
            )
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, close_code):
        user = self.scope["user"]

        if user.is_authenticated:
            await self.channel_layer.group_discard(
                f"user_{user.id}",
                self.channel_name
            )

    # Receive notification from group
    async def send_new_match_notification(self, event):
        match_data = event['match_data']
        # Send message to WebSocket
        await self.send(text_data=json.dumps({
            'message': match_data
        }))


class NotificationConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.user = self.scope['user']
        self.room_group_name = f'notifications_{self.user.id}'
        
        # Join notifications group
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        # Leave notifications group
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    # Send notification to WebSocket
    async def send_notification(self, event):
        notification_type = event['notification_type']
        message = event['message']
        
        # Send notification data to WebSocket
        await self.send(text_data=json.dumps({
            'notification_type': notification_type,
            'message': message
        }))


def notify_user(user_id, notification_type, message):
    channel_layer = get_channel_layer()
    async_to_sync(channel_layer.group_send)(
        f'notifications_{user_id}', {
            'type': 'send_notification',
            'notification_type': notification_type,
            'message': message,
        }
    )



class TokenConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        user = self.scope['user']
        if user.is_authenticated:
            # Group name will be unique to the user (e.g., "user_tokens_1")
            self.group_name = f"user_tokens_{user.id}"

            # Add this connection to the user's token group
            await self.channel_layer.group_add(
                self.group_name,
                self.channel_name
            )
            await self.accept()
        else:
            await self.close()

    async def disconnect(self, close_code):
        # Remove the user from their token group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    # Method to handle real-time token updates sent to the user
    async def token_update(self, event):
        token_balance = event['token_balance']

        # Send the updated token balance to the WebSocket
        await self.send(text_data=json.dumps({
            'token_balance': token_balance
        }))
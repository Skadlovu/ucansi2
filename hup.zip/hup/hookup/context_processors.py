# context_processors.py

from .models import Wink, Like, Message

def notifications_processor(request):
    """
    Context processor to add notifications (winks, likes, unread messages) to all templates.
    """
    if request.user.is_authenticated:
        # Fetch counts for notifications
        winks_count = Wink.objects.filter(receiver=request.user, viewed=False).count()
        likes_count = Like.objects.filter(receiver=request.user, viewed=False).count()
        unread_messages_count = Message.objects.filter(receiver=request.user, is_read=False).count()

        # Total alerts (sum of winks and likes)
        total_alerts_count = winks_count + likes_count
        
        # Return as a dictionary to be accessible in templates
        return {
            'notifications': {
                'winks_count': winks_count,
                'likes_count': likes_count,
                'unread_messages_count': unread_messages_count,
                'total_alerts_count': total_alerts_count,  # Include total alerts count
            }
        }
    else:
        return {}



def token_balance(request):
    """
    Context processor that adds token balance to all template contexts.
    Also includes the WebSocket connection URL for real-time updates.
    """
    context = {
        'token_balance': 0,
        'ws_token_url': f"{'wss' if request.is_secure() else 'ws'}://{request.get_host()}/ws/tokens/"
    }
    
    if request.user.is_authenticated:
        try:
            context['token_balance'] = request.user.userprofile.tokens
        except AttributeError:
            # Handle case where profile doesn't exist yet
            pass
            
    return context
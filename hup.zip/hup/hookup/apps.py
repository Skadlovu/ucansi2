from django.apps import AppConfig


class HookupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hookup'


    def ready(self):
        import hookup.models 
from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone
from datetime import timedelta
import uuid
from django.utils import timezone
from django.urls import reverse
import math
from django.db.models import Q
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.core.validators import MinValueValidator
from decimal import Decimal
from django.db import transaction




def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate the distance between two points on Earth using the Haversine formula.
    The result is returned in kilometers.
    """
    R = 6371  # Radius of the Earth in kilometers
    lat1, lon1, lat2, lon2 = map(math.radians, [lat1, lon1, lat2, lon2])

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))

    return R * c

class MatchManager(models.Manager):
    def find_matches(self, user, max_distance_km=50):
        user_profile = user.userprofile
        
        # Ensure the user has latitude and longitude
        if not (user_profile.latitude and user_profile.longitude):
            return self.none()  # Return no matches if the user's location is missing

        user_lat = user_profile.latitude
        user_lon = user_profile.longitude

        # Initial filtering by preferences (gender, age, body type, etc.)
        candidates = UserProfile.objects.filter(
            Q(gender=user_profile.gender_preference),
            Q(age__gte=user_profile.min_age_preference),
            Q(age__lte=user_profile.max_age_preference),
            Q(body_type=user_profile.body_type_preference),
            Q(smoking=user_profile.smoking_preference),
            Q(drinking=user_profile.drinking_preference)
        ).exclude(user=user)

        # Optional: filter by shared interests
        if user_profile.interest_preference.exists():
            candidates = candidates.filter(
                interests__in=user_profile.interest_preference.all()
            ).distinct()

        # Filter candidates based on proximity (using Haversine formula)
        matches = []
        for candidate in candidates:
            if candidate.latitude and candidate.longitude:
                distance = haversine_distance(user_lat, user_lon, candidate.latitude, candidate.longitude)
                if distance <= max_distance_km:
                    matches.append(candidate)

        # Return sorted matches based on distance
        matches.sort(key=lambda candidate: haversine_distance(user_lat, user_lon, candidate.latitude, candidate.longitude))
        
        return matches






class Referral(models.Model):
    referrer = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='referrals_made'
    )
    referred_user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='referred_by'
    )
    referral_code = models.CharField(max_length=20, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    referrer_awarded = models.BooleanField(
        default=False,
        help_text="Indicates whether the referrer has been awarded their tokens"
    )

    class Meta:
        indexes = [
            models.Index(fields=['referral_code']),
            models.Index(fields=['referred_user']),
        ]

    def __str__(self):
        return f"Referral by {self.referrer.username}"

class Interest(models.Model):
    name = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.name
    

# Choices for various profile attributes
BODY_TYPES = [
    ('slim', 'Slim'),
    ('average', 'Average'),
    ('athletic', 'Athletic'),
    ('curvy', 'Curvy'),
    ('muscular', 'Muscular'),
    ('heavy', 'Heavy'),
]

BODY_TYPE_PREFERENCE = [
    ('slim', 'Slim'),
    ('average', 'Average'),
    ('athletic', 'Athletic'),
    ('curvy', 'Curvy'),
    ('muscular', 'Muscular'),
    ('heavy', 'Heavy'),
    ('open','Open'),
]


HAIR_COLORS = [
    ('black', 'Black'),
    ('brown', 'Brown'),
    ('blonde', 'Blonde'),
    ('red', 'Red'),
    ('gray', 'Gray'),
    ('other', 'Other'),
]

HEIGHT_CHOICES = [
    ('150', '150 cm'),
    ('155', '155 cm'),
    ('160', '160 cm'),
    ('165', '165 cm'),
    ('170', '170 cm'),
    ('175', '175 cm'),
    ('180', '180 cm'),
    ('185', '185 cm'),
    ('190', '190 cm'),
    ('195', '195 cm'),
    ('200', '200 cm'),
]
EDUCATION_LEVELS = [
    ('high_school', 'High School'),
    ('bachelors', 'Bachelors'),
    ('masters', 'Masters'),
    ('phd', 'PhD'),
    ('other', 'Other'),
]

RELATIONSHIP_GOALS = [
    ('short_term', 'Short-term Relationship'),
    ('long_term', 'Long-term Relationship'),
    ('casual', 'Casual Dating'),
    ('friendship', 'Friendship'),
    ('other', 'Other'),
]

PREFERENCE_CHOICES=[
    ('dont_care','Dont care'),
    ('no','No'),
    ('yes','Yes')
]
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='hookup_profile_pictures/', default='' ,null=True, blank=True)
    profile_picture_approved = models.BooleanField(default=False)
    
    # Physical attributes
    age = models.IntegerField(null=True, blank=True)
    height = models.CharField(max_length=30,choices=HEIGHT_CHOICES, null=True, blank=True)  # In meters or cm
    body_type = models.CharField(max_length=10, choices=BODY_TYPES, blank=True)
    hair_color = models.CharField(max_length=10, choices=HAIR_COLORS, blank=True)
    smoking = models.BooleanField(default=False)  # Does the user smoke?
    drinking = models.BooleanField(default=False)  # Does the user drink?
    interests = models.ManyToManyField(Interest, blank=True, related_name='user_interest')
    
    # Personal details
    education = models.CharField(max_length=20, choices=EDUCATION_LEVELS, blank=True)
    occupation = models.CharField(max_length=100, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)  # Free text bio/description
    
    # Location (for proximity-based matching)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)
    
    # Preferences for match
    gender_preference = models.CharField(max_length=10, choices=[('male', 'Male'), ('female', 'Female'), ('both', 'Both')], blank=True)
    min_age_preference = models.IntegerField(null=True, blank=True)
    max_age_preference = models.IntegerField(null=True, blank=True)
    body_type_preference = models.CharField(max_length=10, choices=BODY_TYPE_PREFERENCE, blank=True, null=True)
    smoking_preference =  models.CharField(max_length=30,choices=PREFERENCE_CHOICES,null=True, blank=True)  # Preference for smoking habits
    drinking_preference =  models.CharField(max_length=30,choices=PREFERENCE_CHOICES,null=True, blank=True)  # Preference for drinking habits
    interest_preference = models.ManyToManyField(Interest, blank=True)
    
    
    # Lifestyle and relationship goals
    relationship_goal = models.CharField(max_length=20, choices=RELATIONSHIP_GOALS, blank=True)
    
    # Tokens for interactions
    tokens = models.IntegerField(default=0)
    is_profile_completed = models.BooleanField(default=False)
    signup_bonus_awarded = models.BooleanField(
        default=False,
        help_text="Indicates whether the initial signup bonus tokens have been awarded"
    )
    objects = MatchManager()
    # Time tracking
    joined_date = models.DateTimeField(default=timezone.now)
    is_email_verified = models.BooleanField(default=False)
    is_completed=models.BooleanField(default=False,blank=True, null=True)

    def __str__(self):
        return self.user.username

    def calculate_age(self, birth_date):
        """
        Utility method to calculate the age from the birth date, if needed.
        """
        today = timezone.now().date()
        return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

    # Example method to check if a user matches preferences (used in match algorithms)
    def matches_preferences(self, other_user_profile):
        """
        Returns True if `other_user_profile` matches the user's preferences.
        Example checks can include age range, body type, gender preference, etc.
        """
        # Check age preference
        if other_user_profile.age and (other_user_profile.age < self.min_age_preference or other_user_profile.age > self.max_age_preference):
            return False
        
        # Check gender preference
        if self.gender_preference and other_user_profile.user.gender != self.gender_preference:
            return False

        # Check body type preference
        if self.body_type_preference and other_user_profile.body_type != self.body_type_preference:
            return False
        
        # You can extend this to check more preferences
        
        return True
    
@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    if not hasattr(instance, 'userprofile'):
        UserProfile.objects.create(user=instance)
    instance.userprofile.save()   







class Wink(models.Model):
    sender = models.ForeignKey(User, related_name='sent_winks', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_winks', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=timezone.now)     
    viewed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender.username} winked at {self.receiver.username}"

class Like(models.Model):
    sender = models.ForeignKey(User, related_name='sent_likes', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_likes', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=timezone.now)
    viewed = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender.username} liked {self.receiver.username}"

class Message(models.Model):
    sender = models.ForeignKey(User, related_name='sent_messages', on_delete=models.CASCADE)
    receiver = models.ForeignKey(User, related_name='received_messages', on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.sender.username} messaged {self.receiver.username}: {self.content[:30]}"
    
class TokenPackage(models.Model):
    """
    Represents purchasable token packages.
    
    This model stores information about different token packages that users can purchase,
    including pricing, token amounts, and status tracking.
    """
    name = models.CharField(
        max_length=100,
        help_text="Name of the token package"
    )
    tokens = models.IntegerField(
        validators=[MinValueValidator(1)],
        help_text="Number of tokens included in the package"
    )
    price = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        validators=[MinValueValidator(Decimal('0.01'))],
        help_text="Price in Rands (ZAR)"
    )
    description = models.TextField(
        blank=True,
        help_text="Detailed description of the token package"
    )
    is_active = models.BooleanField(
        default=True,
        help_text="Whether this package is currently available for purchase"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    @property
    def price_per_token(self):
        """Calculate the price per token."""
        return self.price / self.tokens if self.tokens > 0 else None

    @property
    def is_promotional(self):
        """Check if this is a promotional package based on price per token."""
        if not hasattr(self, '_avg_price_per_token'):
            # Calculate average price per token across all active packages
            active_packages = TokenPackage.objects.filter(is_active=True)
            prices_per_token = [pkg.price_per_token for pkg in active_packages if pkg.price_per_token]
            self._avg_price_per_token = sum(prices_per_token) / len(prices_per_token) if prices_per_token else 0
        
        return self.price_per_token < self._avg_price_per_token

    def __str__(self):
        return f"{self.name} ({self.tokens} tokens for R{self.price})"

    class Meta:
        ordering = ['price']
        indexes = [
            models.Index(fields=['is_active']),
            models.Index(fields=['price']),
        ]
        verbose_name = 'Token Package'
        verbose_name_plural = 'Token Packages'

class Subscription(models.Model):
    """Handles uncapped plan subscriptions."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    start_date = models.DateTimeField(default=timezone.now)
    end_date = models.DateTimeField()  # Set dynamically upon purchase

    @property
    def is_active(self):
        """Check if the subscription is still valid."""
        return timezone.now() < self.end_date

    def save(self, *args, **kwargs):
        if not self.end_date:
            self.end_date = timezone.now() + timedelta(days=30)  # Set expiration for 30 days
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.user.username} - Uncapped until {self.end_date}'
    


class ProfilePicture(models.Model):
    """Additional pictures for the user's profile (up to 4)."""
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='profile_pictures/', null=True, blank=True)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.user.username}'s picture uploaded on {self.timestamp}"
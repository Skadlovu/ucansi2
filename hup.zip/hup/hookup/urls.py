from django.urls import path
from .views import verify_email
from django.contrib.auth import views as auth_views
from.views import match_list, profile_detail,message_detail,messages_list,send_message,buy_uncapped,payfast_notify,buy_tokens,upload_additional_pictures,upload_profile_picture,winks_list,likes_list,token_purchase_view,gift_tokens,generate_referral_link,signup_with_referral,connections_list, user_search,home,register,verify_email_notice,update_profile,login_view
from.consumers import MessageConsumer,NotificationConsumer,TokenConsumer
from. import views

app_name='hookup'
 
urlpatterns = [
    path('', home, name='home'),
    path('hookup/register/',register,name='register'),
    path('verify-email/<uidb64>/<token>/', verify_email, name='verify_email'),
    path('hookup/login', login_view, name="hookup_login"),
    path('hookup/logout',auth_views.LogoutView.as_view(template_name='hookup/logout.html'), name="hookup_logout"),
    path('hookup/password_reset/', auth_views.PasswordResetView.as_view(template_name='hookup/password_reset.html'), name='hookup_password_reset'),
    path('reset_done',auth_views.PasswordChangeDoneView.as_view(), name='password_change'),
    path('hookup/profile/update/', update_profile, name='update_profile'),
    path('hookup/profile/<int:user_id>/', profile_detail, name='profile_detail'),
    path('hookup/matches/', match_list, name='match_list'),
    path('ws/chat/<int:receiver_id>/', MessageConsumer.as_asgi(), name='chat_socket'),
    path('ws/notifications/', NotificationConsumer.as_asgi(), name='notification_socket'),
    path('hookup/messages/', messages_list, name='messages_list'),  # View for all conversations
    path('hookup/messages/<int:user_id>/', message_detail, name='message_detail'),  # View for a specific conversation
    path('hookup/messages/send/<int:user_id>/', send_message, name='send_message'),  # Endpoint to send a new message
    path('hookup/buy-tokens/<int:package_id>/', buy_tokens, name='buy_tokens'),
    path('hookup/buy-uncapped/', buy_uncapped, name='buy_uncapped'),
    path('payfast-notify/', payfast_notify, name='payfast_notify'), 
    path('ws/tokens/', TokenConsumer.as_asgi()), 
    path('hookup/upload-profile-picture/', upload_profile_picture, name='upload_profile_picture'),
    path('hookup/upload-additional-pictures/', upload_additional_pictures, name='upload_additional_pictures'),
    path('hookup/winks/', winks_list, name='winks_list'),
    path('hookup/likes/', likes_list, name='likes_list'),
    path('send-wink/<int:user_id>/', views.send_wink, name='send_wink'),
    path('send-like/<int:user_id>/', views.send_like, name='send_like'),
    path('hookup/tokens/',token_purchase_view,name='token'),
    path('hookup/gift_tokens/',gift_tokens, name='gift'),
    path('hookup/generate-referral-link/', generate_referral_link, name='generate_referral_link'),
    path('hookup/signup/<uuid:referral_code>/', signup_with_referral, name='signup_with_referral'),
    path('hookup/connections/', connections_list, name='connections_list'),
    path('hookup/search/', user_search, name='user_search'),
    path('hookup/verify_email_notice/',verify_email_notice,name='email_notice'),
   # path('interest-autocomplete/', views.InterestAutocomplete.as_view(), name='interest-autocomplete'),



]
